=== Plugin Name ===
Plugin Name: BrandCaptcha
Plugin URI: http://www.pontamedia.com/
Description: Integrates PontaMedia's BandCaptcha anti-spam solutions with drupal
Version: 1.1.0
Author: Pontamedia 
Email: soporte@pontamedia.com
Author URI: http://www.pontamedia.com
License: GPL2